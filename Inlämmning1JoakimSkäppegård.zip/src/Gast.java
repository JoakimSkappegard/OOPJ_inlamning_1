public interface Gast {
    public void sattGastState(boolean state);
    public boolean getGastState();
}
