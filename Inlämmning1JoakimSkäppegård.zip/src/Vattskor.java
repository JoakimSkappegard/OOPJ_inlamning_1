public enum Vattskor {
    KRANVATTEN ("kranvatten"),
    MINERALVATTEN ("mineralvatten"),
    PROTEINDRYCK ("proteindryck");
    public final String vattska;

    Vattskor(String v) {
        vattska = v;
    }
}
