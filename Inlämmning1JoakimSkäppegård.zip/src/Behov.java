public interface Behov {
    public double behov();
    public Vattskor vattskaBehov();
}
